import { Link } from "react-router-dom";

export default function ProductCard({ item }) {
  return (
    <Link
      to={`/product/read/${item.productId}`}
      className="block border rounded-xl p-3 hover:shadow"
    >
      <img
        src={item.thumbnailUrl}
        alt="thumb"
        className="w-full h-40 object-cover rounded"
      />
      <div className="mt-2 font-medium truncate">{item.title}</div>
      <div className="text-sm text-gray-500">
        {item.price?.toLocaleString?.() ?? item.price}원 · {item.tradeLocation}
      </div>
      <div className="text-xs text-gray-400">
        {item.conditionStatus} · {item.status}
      </div>
    </Link>
  );
}
