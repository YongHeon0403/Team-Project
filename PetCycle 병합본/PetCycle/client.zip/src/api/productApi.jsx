import jwtAxios from "../util/JWTUtil";

export const listCategories = async () => {
  const { data } = await jwtAxios.get(`/api/product-categories`);
  return data; // [{categoryId, categoryName, parentCategoryId, petTypeId}, ...]
};

export const listProducts = async ({
  page = 0,
  size = 12,
  categoryId,
  keyword,
  status,
  sellerId,
} = {}) => {
  const params = { page, size };
  if (categoryId != null) params.categoryId = categoryId;
  if (keyword) params.keyword = keyword;
  if (status) params.status = status;
  if (sellerId) params.sellerId = sellerId;
  const { data } = await jwtAxios.get(`/api/products`, { params });
  return data; // Spring Page<ProductListResponseDto>
};

export const getProduct = async (productId) => {
  const { data } = await jwtAxios.get(`/api/products/${productId}`);
  return data; // ProductDetailResponseDto
};

export const registerProduct = async (dto, images = []) => {
  const fd = new FormData();
  fd.append(
    "product",
    new Blob([JSON.stringify(dto)], { type: "application/json" })
  );
  images.slice(0, 5).forEach((file) => fd.append("images", file));
  const { data } = await jwtAxios.post(`/api/products`, fd, {
    headers: { "Content-Type": "multipart/form-data" },
  });
  return data; // productId
};

export const updateProduct = async (
  productId,
  dto,
  addImages = [],
  deleteImageIds = []
) => {
  const fd = new FormData();
  fd.append(
    "product",
    new Blob([JSON.stringify(dto)], { type: "application/json" })
  );
  addImages.slice(0, 5).forEach((file) => fd.append("images", file));
  await jwtAxios.put(`/api/products/${productId}`, fd, {
    headers: { "Content-Type": "multipart/form-data" },
  });
  // 서버가 이미지 삭제는 별도 엔드포인트이므로 순차 삭제
  await Promise.all(
    deleteImageIds.map((id) => jwtAxios.delete(`/api/products/images/${id}`))
  );
};

export const deleteProduct = async (productId) => {
  await jwtAxios.delete(`/api/products/${productId}`);
};

export const toggleLike = async (productId) => {
  const { data } = await jwtAxios.post(`/api/products/${productId}/like`);
  return data; // { productId, liked, likeCount }
};
