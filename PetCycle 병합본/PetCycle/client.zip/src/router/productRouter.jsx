import { lazy } from "react";

const ProductIndex = lazy(() => import("../pages/product/Index.jsx"));
const ProductList = lazy(() => import("../pages/product/List.jsx"));
const ProductAdd = lazy(() => import("../pages/product/Add.jsx"));
const ProductRead = lazy(() => import("../pages/product/Read.jsx"));
const ProductModify = lazy(() => import("../pages/product/Modify.jsx"));

export default [
  {
    path: "/product",
    element: <ProductIndex />,
    children: [
      { index: true, element: <ProductList /> },
      { path: "list", element: <ProductList /> },
      { path: "add", element: <ProductAdd /> },
      { path: "read/:productId", element: <ProductRead /> },
      { path: "modify/:productId", element: <ProductModify /> },
    ],
  },
];
