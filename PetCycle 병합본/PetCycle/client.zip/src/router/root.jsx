// src/router/root.jsx
import { lazy, Suspense } from "react";
import { createBrowserRouter } from "react-router-dom";
import React from "react";

import UserRouter from "./UserRouter";
import BoardRouter from "./BoardRouter";
import ProductRouter from "./ProductRouter";

const Loading = <div>Loading...</div>;
const Main = lazy(() => import("../pages/MainPages"));

const root = createBrowserRouter([
  {
    path: "/",
    element: (
      <Suspense fallback={Loading}>
        <Main />
      </Suspense>
    ),
  },
  {
    path: "/user",
    children: UserRouter(),
  },
  {
    path: "/board",
    children: BoardRouter(),
  },
  {
    path: "/product",
    children: ProductRouter,
  },
]);

export default root;
