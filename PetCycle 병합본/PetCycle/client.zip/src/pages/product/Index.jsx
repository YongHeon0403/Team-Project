import { Outlet, Link } from "react-router-dom";

export default function ProductIndex() {
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-bold">상품</h1>
        <Link to="/product/add" className="btn btn-primary">
          등록
        </Link>
      </div>
      <Outlet />
    </div>
  );
}
