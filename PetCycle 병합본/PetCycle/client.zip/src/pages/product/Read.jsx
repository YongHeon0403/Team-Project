// src/pages/product/Read.jsx
import { useEffect, useState } from "react";
import { useNavigate, useParams, Link } from "react-router-dom";
import { getProduct, deleteProduct, toggleLike } from "../../api/productApi";
import { createOrGetRoom } from "../../api/chatApi";
import { registerTransaction } from "../../api/orderApi"; // ★ 추가

export default function ProductRead() {
  const { productId } = useParams();
  const nav = useNavigate();
  const [data, setData] = useState(null);

  useEffect(() => {
    getProduct(productId).then(setData);
  }, [productId]);

  const onDelete = async () => {
    if (!confirm("정말 삭제하시겠습니까?")) return;
    await deleteProduct(productId);
    nav("/product/list");
  };

  const onLike = async () => {
    const res = await toggleLike(productId);
    setData((d) => ({ ...d, isLiked: res.liked }));
  };

  // ✅ 채팅 + 거래 동시 시작
  const onChatAndDealStart = async () => {
    const pid = Number(productId);
    // 1) 채팅방 생성/가져오기
    const roomId = await createOrGetRoom(pid);

    // 2) 거래 생성 (실패해도 채팅은 열어줌)
    let txId = null;
    try {
      txId = await registerTransaction({
        productId: pid,
        finalPrice: data.price,
      });
    } catch (e) {
      // 중복 거래 등으로 실패할 수 있으므로 채팅은 계속 진행
      console.warn("registerTransaction failed:", e?.message || e);
      alert(
        "이미 진행 중인 거래가 있거나 생성에 실패했어요. 채팅으로 계속 진행합니다."
      );
    }

    // 3) 채팅방으로 이동(+ 생성된 거래 id 전달)
    nav(`/chat/room/${roomId}${txId ? `?tx=${txId}` : ""}`);
  };

  if (!data) return null;

  return (
    <div className="space-y-4">
      <div className="flex gap-4">
        <div className="w-1/2">
          <div className="aspect-square bg-gray-50 rounded overflow-hidden">
            {data.images?.[0] && (
              <img
                src={data.images[0].imageUrl}
                className="w-full h-full object-cover"
              />
            )}
          </div>
          <div className="mt-2 grid grid-cols-5 gap-2">
            {data.images?.slice(0, 5).map((img) => (
              <img
                key={img.imageId}
                className="h-20 object-cover rounded"
                src={img.imageUrl}
              />
            ))}
          </div>
        </div>

        <div className="flex-1 space-y-2">
          <div className="text-2xl font-bold">{data.title}</div>
          <div className="text-xl">{data.price?.toLocaleString?.()}원</div>
          <div className="text-sm text-gray-500">
            {data.tradeLocation} · {data.conditionStatus}
          </div>
          <div className="flex gap-2 mt-2">
            {data.tags?.map((t) => (
              <span key={t} className="badge badge-outline">
                #{t}
              </span>
            ))}
          </div>
          <div className="pt-2 flex gap-2">
            <button className="btn" onClick={onLike}>
              {data.isLiked ? "찜취소" : "찜하기"}
            </button>
            {/* 🔽 여기 버튼 교체 */}
            <button className="btn btn-primary" onClick={onChatAndDealStart}>
              채팅하기(바로 거래)
            </button>
            <Link to={`/product/modify/${productId}`} className="btn">
              수정
            </Link>
            <button className="btn btn-error" onClick={onDelete}>
              삭제
            </button>
          </div>
        </div>
      </div>

      <div className="prose max-w-none">
        <h3>상세 설명</h3>
        <p>{data.description}</p>
      </div>
    </div>
  );
}
