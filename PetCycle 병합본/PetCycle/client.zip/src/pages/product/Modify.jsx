import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import ProductForm from "../../components/product/ProductForm";
import { getProduct, updateProduct } from "../../api/productApi";

export default function ProductModify() {
  const { productId } = useParams();
  const nav = useNavigate();
  const [initial, setInitial] = useState(null);

  useEffect(() => {
    getProduct(productId).then((d) => {
      setInitial({
        ...d,
        categoryId: d.category?.categoryId,
        tagNames: d.tags || [],
      });
    });
  }, [productId]);

  const submit = async (form, addImages) => {
    await updateProduct(
      productId,
      {
        ...form,
        price: form.price ? Number(form.price) : null,
        latitude: form.latitude ? Number(form.latitude) : null,
        longitude: form.longitude ? Number(form.longitude) : null,
        categoryId: Number(form.categoryId),
        status: form.status || undefined,
      },
      addImages,
      [] // TODO: 이미지 삭제 UI에서 선택된 imageId 배열 전달
    );
    nav(`/product/read/${productId}`);
  };

  if (!initial) return null;
  return <ProductForm initial={initial} onSubmit={submit} submitText="수정" />;
}
