// client/src/pages/product/List.jsx
import { useEffect, useMemo, useState } from "react";
import { listProducts } from "../../api/productApi";
import ProductCard from "../../components/product/ProductCard";
import useCustomMove from "../../hooks/useCustomMove";
import PageComponent from "../../components/common/PageComponent";

export default function ProductList() {
  const {
    page = 0,
    size = 12,
    moveToList,
  } = useCustomMove({ basePath: "/product" });

  const [keyword, setKeyword] = useState("");
  const [status, setStatus] = useState("");
  const [serverData, setServerData] = useState(null);
  const [fetching, setFetching] = useState(false);
  const [result, setResult] = useState(null);

  const query = useMemo(
    () => ({
      page,
      size,
      keyword: keyword || undefined,
      status: status || undefined,
    }),
    [page, size, keyword, status]
  );

  const apiQuery = useMemo(
    () => ({ ...query, page: Math.max(0, (query.page || 1) - 1) }),
    [query]
  );

  const toTemplatePaging = (pageData) => {
    if (!pageData)
      return { prev: false, next: false, pageNumList: [], current: 1 };
    const current = (pageData.number ?? 0) + 1;
    const total = pageData.totalPages ?? 1;
    return {
      prev: current > 1,
      next: current < total,
      prevPage: current - 1,
      nextPage: current + 1,
      pageNumList: Array.from({ length: total }, (_, i) => i + 1),
      current,
    };
  };

  useEffect(() => {
    const fetchData = async () => {
      try {
        setFetching(true);
        const res = await listProducts(apiQuery);
        setServerData(res);
      } catch (e) {
        setResult({
          title: "조회 실패",
          content: e?.message || "상품 목록을 불러오지 못했습니다.",
        });
      } finally {
        setFetching(false);
      }
    };
    fetchData();
  }, [apiQuery.page, apiQuery.size, apiQuery.status, apiQuery.keyword]);

  return (
    <div>
      {fetching && (
        <div className="mb-2 rounded bg-gray-100 p-2 text-sm">로딩 중...</div>
      )}
      {result && (
        <div className="mb-2 rounded bg-red-50 p-3 text-sm text-red-600">
          <div className="font-semibold">{result.title}</div>
          <div>{result.content}</div>
          <button className="btn btn-xs mt-2" onClick={() => setResult(null)}>
            닫기
          </button>
        </div>
      )}

      <div className="mb-3 flex gap-2">
        <input
          className="input input-bordered"
          placeholder="검색"
          value={keyword}
          onChange={(e) => setKeyword(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && setResult(null)}
        />
        <select
          className="select select-bordered"
          value={status}
          onChange={(e) => setStatus(e.target.value)}
        >
          <option value="">상태 전체</option>
          <option value="SELLING">판매</option>
          <option value="RESERVED">예약중</option>
          <option value="SOLD">판매완료</option>
        </select>
        <button className="btn" onClick={() => setResult(null)}>
          검색
        </button>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
        {serverData?.content?.map((item) => (
          <ProductCard key={item.productId} item={item} />
        ))}
      </div>

      <div className="mt-4">
        <PageComponent
          serverData={toTemplatePaging(serverData)}
          movePage={(obj) => moveToList({ page: obj.page, size })}
        />
      </div>
    </div>
  );
}
