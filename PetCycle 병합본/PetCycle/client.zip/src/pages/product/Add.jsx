import { useNavigate } from "react-router-dom";
import ProductForm from "../../components/product/ProductForm";
import { registerProduct } from "../../api/productApi";

export default function ProductAdd() {
  const nav = useNavigate();
  const submit = async (form, images) => {
    const id = await registerProduct(
      {
        ...form,
        price: form.price ? Number(form.price) : null,
        latitude: form.latitude ? Number(form.latitude) : null,
        longitude: form.longitude ? Number(form.longitude) : null,
        categoryId: Number(form.categoryId),
      },
      images
    );
    nav(`/product/read/${id}`);
  };

  return <ProductForm onSubmit={submit} submitText="등록" />;
}
